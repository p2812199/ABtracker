<?php
if (!defined('APPLICATION_LOADED') || !APPLICATION_LOADED) {
    die('No direct script access.');
}
?>
<div id="container">
    <h1>The page you try to open not found!</h1>
    <h2>404</h2>
</div>