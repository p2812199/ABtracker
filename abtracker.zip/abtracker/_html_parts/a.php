<?php
if (DEBUG_MODE === true) {
    ?>
    <div id="debugmode" class="container">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th colspan="2" class="text-center">MySQL Queries</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($this->connections as $c) {
                        ?>
                        <tr class="warning">
                            <td><?= $c['time'] ?></td>
                            <td><?= $c['result'] ?></td>
                        </tr>
                        <?php
                    }
                    foreach ($this->queries as $q) {
                        ?>
                        <tr class="success">
                            <td><?= $q['time'] ?></td>
                            <td><?= htmlspecialchars($q['query']) ?></td>
                        </tr>
                    <?php }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
<?php }
?>