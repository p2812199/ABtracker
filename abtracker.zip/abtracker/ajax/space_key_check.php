<?php
echo $this->spaceKeyCheck($_POST['space_key']);
?>